import requests
import os
import time
import json

apiKey = "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQzNjA4NjcwNiwiYWFpIjoxMSwidWlkIjo2NTg5MjkyOCwiaWFkIjoiMjAyNC0xMS0xM1QxMjo1NTozNS4wNjVaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6MTU2NTE0MzMsInJnbiI6ImV1YzEifQ.JOq8JPaRwXaRS5kP0EowpK8Fwv3L2RdcljxpaTkLX8c"
apiUrl = "https://api.monday.com/v2"
headers = {"Authorization": apiKey}


def find_id_by_column_value(board_id, column_id, value_to_find):
    query = f"""{{ boards (ids:{board_id}) {{
         items_page (limit :1,query_params:{{rules:[{{column_id: "{column_id}", compare_value: "{value_to_find}", operator: any_of}}]}}) {{
           items {{
           id
           }} }} }} }}"""

    r = requests.post(url=apiUrl, json={'query': query}, headers=headers)  # make request
    print(r.content)
    if ("high-volume traffic" in r.text):
        print("requesting the API too much, need to sleep 30s")
        time.sleep(30)
        find_id_by_column_value(board_id, column_id, value_to_find)
    else:
        if len(r.json()["data"]["boards"][0]["items_page"]["items"]) > 0:
            return r.json()["data"]["boards"][0]["items_page"]["items"][0]["id"]
        else:
            return -1


query = """{ 
  boards (ids:%s) {
  name
  id
  description
  items_page (limit :1,query_params:{rules:[{column_id: "texte__1", compare_value: ["trkl"]}], operator: contains_text}) {
    items {
    group{
    id
    title 
    }
    name
    id
    column_values {
      id
      type
      text
} } } } }""" % 1642973911

# query = 'mutation{ create_item (board_id:1642973911, item_name:"WHAT IS UP MY FRIENDS!") { id } }'
query2 = """mutation {
  change_simple_column_value(item_id: 1642974005, board_id: 1642973911, column_id: "texte__1", value: "OUAAAAIS") {
    id
  }
}"""
query10 = f"""{{boards(ids: {1719340424}) {{
                   columns{{settings_str}}}}}}"""
query3 = """{ 
  boards (ids:%s) {
groups{
id}
items_page{

    items{
    id

    column_values{
    id
    text
    ... on BoardRelationValue {
                linked_item_ids
                linked_items{
                    name
                }}
    }
    
    
    
    }
    
        
} } }""" % 1641389645

query4 = """{ 
  boards (ids:%s) {
    
    groups{
    title
    id
    }
  }
}
""" % 1706529346

query5 = f"""{{boards(ids: {1719340424}) {{
        columns{{
          id
          title}}}}}}"""

query6 = """mutation {
         create_item (board_id: 1704649887, group_id: "nouveau_groupe74816__1", item_name: "42186000AH0295", column_values: "{\\"connecter_les_tableaux__1\\": \\"{'item_ids': ['1660102440']}\\"}" ) {
               id
             }
           }"""

query7 = f"""{{ boards (ids:{1706529346}) {{
          items_page (limit :1,query_params:{{rules:[{{column_id: "{"siren__1"}", compare_value: "{"214202186"}", operator: any_of}}]}}) {{
            items {{
            id
            }} }} }} }}"""
# Converting the time in seconds to a timestamp

pro_txt = "propri_taire6__1"
pro_link = "connecter_les_tableaux5__1"
sta_txt = "poste_source9__1"
sta_link = "connecter_les_tableaux__1"
qtxt = "qualit_7__1"
qcla = "classement__1"

data = {'query': query3}



response = requests.post(apiUrl, json=data, headers=headers)
print(response.content)
liste = []

'''
station_board_id = 1641391677
code_column_id_station_board = "name"
station_id = find_id_by_column_value(station_board_id, code_column_id_station_board,
                                                  liste[0]["poste"])
connect_station_board_value = {"item_ids": [station_id]}


item_id = liste[0]["id"]


write_query = """mutation ($columnVals: JSON!) {
       change_multiple_column_values(
       board_id:%s, 
       item_id:%s, 
       column_values:$columnVals) 
       { id } }""" % (1719340424, item_id)

vars = {
    'columnVals': json.dumps({
        sta_link: connect_station_board_value,
        qcla: {"rating":int( liste[0]["qualite"])}
        
    })
}

data = {'query': write_query, 'variables': vars}

r = requests.post(url=apiUrl, json=data, headers=headers)''' # make request

a= json.dumps({
    "a":1,
    "b":1
})
print(a)

# query4 = """mutation {
#   change_simple_column_value(item_id: %s, board_id: 1691536624, column_id: "long_texte__1", value: "OUAAAAIS") {
#     id
#   }
# }"""%r.json()["data"]["boards"][0]["groups"][0]["items_page"]["items"][0]['id']


# data = {'query' : query4}

# r = requests.post(url=apiUrl, json=data, headers=headers) # make request
# print(r.json())




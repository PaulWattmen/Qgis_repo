import requests
import json
import os
import threading
import time

apiKey = "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQzNjA4NjcwNiwiYWFpIjoxMSwidWlkIjo2NTg5MjkyOCwiaWFkIjoiMjAyNC0xMS0xM1QxMjo1NTozNS4wNjVaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6MTU2NTE0MzMsInJnbiI6ImV1YzEifQ.JOq8JPaRwXaRS5kP0EowpK8Fwv3L2RdcljxpaTkLX8c"
apiUrl = "https://api.monday.com/v2"
headers = {"Authorization" : apiKey}
board_id = 1719340424
geojson_folder = "/Users/Wattmen/Documents/qgisproj/traitement/regional_filtre_avancé"
name_group_crible = "nouveau_groupe14626__1"
dep_column_id ="texte__1"
geom_column_id = "long_texte__1"

def readGeojson(path):
    with open(path, 'r', encoding='utf-8') as json_file:
        dic = json.load(json_file)
    return dic


def find_id_by_column_value(board_id, column_id, value_to_find):
    query = f"""{{ boards (ids:{board_id}) {{
         items_page (limit :1,query_params:{{rules:[{{column_id: "{column_id}", compare_value: "{value_to_find}", operator: any_of}}]}}) {{
           items {{
           id
           }} }} }} }}"""

    r = requests.post(url=apiUrl, json={'query': query}, headers=headers)  # make request

    if ("high-volume traffic" in r.text):
        print("requesting the API too much, need to sleep 30s")
        time.sleep(30)
        find_id_by_column_value(board_id, column_id, value_to_find)
    else:
        print(r.content)
        if len(r.json()["data"]["boards"][0]["items_page"]["items"]) > 0:
            return r.json()["data"]["boards"][0]["items_page"]["items"][0]["id"]
        else:
            return -1

def get_all_board_items():
    all_items = []
    items_per_page = 500  # Monday API default
    #,query_params: {{rules: {{column_id: "{geom_column_id}",, compare_value: TextValue, operator: is_empty}}}}) {{
    query = f"""{{
              boards(ids: {board_id}) {{
              groups(ids :"{name_group_crible}"){{
                items_page(limit: {items_per_page},query_params: {{rules: {{column_id: "{"texte__1"}",, compare_value: ["38"], operator: any_of}}}}) {{
                
                cursor
                items{{
                  id
                  name
                  column_values{{
                  text
                  ... on BoardRelationValue {{
                linked_item_ids

                }}
                  }}
                  }}
                }}
                }}
              }}
            }}
            """
    response = requests.post(apiUrl, json={'query': query}, headers=headers)
    print(response.content)
    data = response.json()
    cursor = data['data']['boards'][0]['groups'][0]['items_page']['cursor']
    print(data)

    # Extract items and check if there are more items to retrieve
    items = data['data']['boards'][0]['groups'][0]['items_page']['items']
    all_items.extend(items)

    while cursor:
        query = f"""{{
                next_items_page(limit: {items_per_page}, cursor: "{cursor}") {{
                        cursor
                        items{{
                          id
                          name
                          column_values{{
                            text
                                              ... on BoardRelationValue {{
                linked_item_ids

                }}
                            }}
                          }}
                        }}
                        }}
                      
                    
                    """
        response = requests.post(apiUrl, json={'query': query}, headers=headers)
        data = response.json()
        print(data)
        cursor = data['data']['next_items_page']['cursor']


        # Extract items and check if there are more items to retrieve
        items = data['data']['next_items_page']['items']
        all_items.extend(items)

        # If fewer items are returned than requested, you've reached the last page


    return all_items

def write_geom_and_dep_to_monday(plot,dep,geom):
    pro_txt = "propri_taire6__1"
    pro_link = "connecter_les_tableaux6__1"
    sta_txt = "poste_source9__1"
    sta_link = "connecter_les_tableaux9__1"
    qtxt = "qualit_7__1"
    qcla = "classement__1"

    plot_id = plot["id"]
    plot_proprio = plot["column_values"][4]["text"]
    plot_station= plot["column_values"][5]["text"]
    plot_qualite = plot["column_values"][11]["text"]

    station_board_id = 1641391677
    owner_board_id =1641389645

    connect_station_board_value = {"item_ids": [plot["column_values"][3]["linked_item_ids"][0]]}
    connect_owner_board_value = {"item_ids": [plot["column_values"][5]["linked_item_ids"][0]]}


    '''code_column_id_station_board = "name"
    station_id = find_id_by_column_value(station_board_id, code_column_id_station_board,
                                         plot_station)
    connect_station_board_value = {"item_ids": [station_id]}

    owner_id = find_id_by_column_value(owner_board_id, code_column_id_station_board,
                                         plot_proprio)
    connect_owner_board_value = {"item_ids": [owner_id]}'''


    write_query = """mutation ($columnVals: JSON!) {
       change_multiple_column_values(
       board_id:%s, 
       item_id:%s, 
       column_values:$columnVals) 
       { id } }""" % (board_id, plot_id)

    vars = {
        'columnVals': json.dumps({
            #dep_column_id: dep,
            #geom_column_id: "%s" % geom,
            sta_link: connect_station_board_value,
            pro_link: connect_owner_board_value
            #qcla: {"rating": int(plot_qualite)}
        })
    }
    data = {'query': write_query, 'variables': vars}

    r = requests.post(url=apiUrl, json=data, headers=headers)  # make request

def get_dep_and_geom_from_plot(name):
    dep = name[0:2]
    print(name)

    dep_folder = os.path.join(geojson_folder, dep)
    file_list = os.listdir(dep_folder)
    found = False
    geom = ""

    for file in file_list:
        if '.geojson' in file:
            geojson_data = readGeojson(os.path.join(dep_folder, file))
            for data in geojson_data['features']:
                if data['properties']['idu'] == name:
                    found = True
                    geom = data['geometry']
                    geom["coordinates"][0][0] = geom["coordinates"][0][0][0:80]
                    break
            if found:
                break
    if not found:
        print(name + " not found")
    return dep, geom

def execute_thread(plot):
    plot_monday_id = plot['id']
    plot_name = plot['name']
    dep, geom = get_dep_and_geom_from_plot(plot_name)

    write_geom_and_dep_to_monday(plot, dep, geom)

ans_list = get_all_board_items()

print(len(ans_list))
thread_amount = 50
i=1
threads = []
for plot in ans_list:
    t = threading.Thread(target=execute_thread,args=(plot,))
    t.start()
    threads.append(t)
    print(i)
    if i%thread_amount == 0 or i == len(ans_list):
        for t in threads:
            t.join()
        threads = []
    i+=1




